# zzz.R
# Contains the package documentation



#' chebinterp
#'
#' The chebinterp package provides functions for Chebyshev Polynomial function interpolation.
#'
#' @docType package
#' @author Walter Zhang <walterwzhang@chicagobooth.edu>
#' @name chebinterp
#' @noRd
NULL