# chebInterp

This package contains functions written in base R for Chebyshev Polynomial Interpolation.

Package installation:

```R
install.packages("https://github.com/walterwzhang/Chebyshev-Interpolation/raw/master/r-package/chebInterp_0.1.0.tar.gz",
                 repos = NULL, type = "source")
```
See the [vignette](https://walterwzhang.github.io/Chebyshev-Interpolation/articles/chebInterp-Intro.html) for usage examples.
