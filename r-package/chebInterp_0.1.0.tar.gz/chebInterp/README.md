# chebInterp

This package contains functions written in base R for Chebyshev Polynomial Interpolation.

Package installation:

See the vignette for how to use the package.
